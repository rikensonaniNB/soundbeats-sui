using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class selectSong : MonoBehaviour
{
 public void selectedSong(){
    switch (this.gameObject.name)
{
    case "About Time":
   // SceneManager.LoadScene("Noah Kenton - About Time");
    break;
}     
    
}
}

