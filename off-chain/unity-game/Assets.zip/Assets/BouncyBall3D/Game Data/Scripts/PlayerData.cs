using System.Collections;
using System.Collections.Generic;
using UnityEngine;
public class PlayerData 
{
    public static string SelectedNFTName;
    public static string NFTRecipient;
    public static string NFTAddress;
   // public static int balance;
    public static int SelectIndex = 0;
    
   // public static int TokenEanred = 0;
    public static int totalBalance;
}
