﻿namespace Suinet.Rpc.Types
{
    public enum SuiSignatureScheme
    {
        ED25519 = 0,
        //Secp256k1 not yet supported
    }
}
